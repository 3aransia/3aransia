"""This file contains all the exceptions of 3aransia library"""

class SourceLanguageError(Exception):
    """Source language doesn't match the input text"""
